package viewClasses;
import playground.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * This class creates the singleplayer scoreboard of FingerCoin.
 * @author S�leyman Taylan Topalo�lu
 * @version 30.04.2017
 */
public class SingleScorePanel extends JPanel
{
	//properties
	private JLabel chances;
	private int trycount;
	private JPanel nextPanel;
	private JButton gameMenu;
	private GeneralListener cl;
	Field field;
	
	//constructors
	public SingleScorePanel(Field field)
	{
		this.field = field;
		trycount = field.getScore();
		chances = new JLabel("Chances Left: " + trycount + " Tries");
		gameMenu = new JButton("GAME MENU");
		cl = new GeneralListener();
		gameMenu.addActionListener(cl);
		
		setLayout(null);
		gameMenu.setBounds(320, 10, 160, 50);
		chances.setBounds(20, 10, 150, 50);
		add(gameMenu);
		add(chances);
		setPreferredSize(new Dimension(800, 120));
	}
	
	//methods
	/**
	 * Paints the scoreboard.
	 * @param g the Graphics object.
	 */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		g.drawRect(0, 0, 600, 120);
	}
	
//	//testing
//	public static void main(String[] args)
//	{
//		JFrame fr = new JFrame();
//		Field field = new Field();
//		fr.add(new SingleScorePanel());
//		fr.setSize(600, 120);
//		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		fr.setVisible(true);
//	}
}