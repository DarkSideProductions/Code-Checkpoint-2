package viewClasses;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

/**
 * Opens and closes panels in the order that user specifies.
 * @author S�leyman Taylan Topalo�lu
 * @version 07.05.2017
 */
public class GeneralListener implements ActionListener 
{
	/**
	 * Does all tasks of this class.
	 * @param e is the ActionEvent generated as a result of the user's decisions.
	 */
	public void actionPerformed(ActionEvent e) 
	{
		if(((JButton)e.getSource()).getText().equals("Back to main menu"))
		{
			FingerCoinFrame.changePanel("main menu");
		}
		if(((JButton)e.getSource()).getText().equals("Back to settings") && ((JButton)e.getSource()).getClass().getName().equals("viewClasses.InfoPanel"))
		{
			FingerCoinFrame.changePanel("settings");
		}
		if(((JButton)e.getSource()).getText().equals("Credits"))
		{
			
		}
		if(((JButton)e.getSource()).getText().equals("Rules"))
		{
			
		}
		if(((JButton)e.getSource()).getText().equals("Settings"))
		{
			FingerCoinFrame.changePanel("settings");
		}
		if(((JButton)e.getSource()).getText().equals("Single Player"))
		{
			
		}
		if(((JButton)e.getSource()).getText().equals("Multi Player"))
		{
			FingerCoinFrame.changePanel("name selection");
		}
		if(((JButton)e.getSource()).getText().equals("CLICK TO CONTINUE"))
		{
			
		}
		if(((JButton)e.getSource()).getText().equals("GAME MENU") && ((JButton)e.getSource()).getClass().getName().equals("viewClasses.SingleScorePanel"))
		{
			
		}
		if(((JButton)e.getSource()).getText().equals("GAME MENU") && ((JButton)e.getSource()).getClass().getName().equals("viewClasses.MultiScorePanel"))
		{
			
		}
		if(((JButton)e.getSource()).getText().equals("Exit"))
		{
			System.exit(0);
		}
	}
}
