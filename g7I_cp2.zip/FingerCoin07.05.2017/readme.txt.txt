PROJECT GROUP NUMBER: G7I

PROJECT TITLE: Finger Coin

DESCRIPTION OF THE PROJECT: The project�s aim is to create a game using Java language. Program is called Finger Coin which gets its name from the gameplay in which player moves coin like object by using fingers. The atmosphere of the program is nostalgic since it takes its concept from the school game where many players compete to goal with minimum movement.
 
The graphical part of the game possess three coins, a goalpost, a block and ground which alters according to the difficulty which the user selects beforehand. The coins are located one side of the field while the goalpost and the block are located the other side. In the ground the different layers will exist which will be explained further. Block is ahead of the goalpost and moves in different speeds in different difficulties. If the coin interacts with the block the player will lose the game. The player is able to move one coin at a time. Firstly player selects one coin then decides the route the coin will follow. In order to choose the route the player uses arrow keys and changes the direction. After the direction is decided, the speed of the coin can also be determined. There are five values of speed which the coin can travel. After the user selects the speed the coin will be launched. If half of coin�s area exceeds the borders of the background the player will lose the game. Else the player will be allowed to move again. The amount of movement is associated with difficulty and the aim is to finish the game before the maximum number of chances consumed.

In each difficulty level, the background alters and backgrounds may have varying layers in it. The layers have different friction constant. Thus, in each layer change in the speed in the same interval will be different. For instance, in the easiest difficulty level the background will assist the player to keep the coin within the field as well as allowing the coin to move freely in the body of the field. In harder levels, it may not be easy to keep the coin in the field and playing in the goalpost territory will be much harder compared to other levels of difficulties. As the game advances the speed of the block which is in front of the goalpost will move quicker and the amount of movement differs in each level considering the background and the difficulty level.

The game has two different gameplay methods. The one described previously is the single player option. The other gameplay option is the multiplayer format. In multiplayer format, the scores for each player is distributed and instead of playing with the chance limit players will be compared with other players� results. The player who reach goalpost with the minimum amount of the movement will be the winner of the game.

STATUS OF THE PROJECT:The draft codes of main menu, settings, multiplayer name selection and scoreboard panels are largely complete. Also the draft code of the coin 
visual class is complete. There is a little more work to be done, especially regarding the merging of the classes, arranging the components of the GUI's. GamePanel is complete now (has only very unimportant errors) and most of the panels have connections between them. The background music will be added and chosen settings will be stored in a text file. We were able to play the game without menus.

Arda Y�ksel: He wrote the Goal and Field classes which include the mechanics of the game. He also participated in the GamePanel class. Moreover, he wrote the DirectionPanel and the PowerPanel classes.

Ceyhun Emre �zt�rk: He wrote the Goalkeeper and Coin classes which are the elements of the game and Drawable interface which is implemented by the classes he wrote. Then, he made sure all classes of the package "playground" are working. He also participated in the GamePanel class and wrote the FieldVisual class.

S�leyman Taylan Topalo�lu: He wrote the CoinVisual, MainMenuPanel, SingleScorePanel, MultiScorePanel, NameSelectionPanel, FingerCoinFrame, GeneralListener and Settings classes which are some of the view classes and helped O�uzhan for the Credits class a lot.

Mustafa Bay: He wrote the GamePanel, the GoalkeeperVisual and the InfoPanel classes.

Murathan G�kta�: He wrote the GamePanel(Mustafa and him are the people who contributed to the GamePanel class most.).

O�uzhan Ayla: He wrote the Credits and the GoalVisual classes.

